﻿'CID:''+v110R~:#72                             update#=  700;         ''+v110I~
'************************************************************************************''+v110I~
'v110 2017/12/22 StringConstant reset required when lang changed       ''+v110I~
'************************************************************************************''+v110I~
Module Main                                                            ''+v110R~
    <STAThread()> Sub Main()                                           ''+v110I~
        Application.Run(New Form1())                                   ''+v110I~
    End Sub                                                            ''+v110I~
End Module
