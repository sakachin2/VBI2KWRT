﻿# README.md 

VBI2KWRT                 2021/08/09  V2.09

Tool of generating Japanese-Kana text file for Braille tool:WinBES99
from Kanji-Kana-Mixed text extracting from image file 
using "Microsoft OCR Library for Windows" (Windows10).
DictionaryDialog is for Mistranslation,
WordDialog(FrequentlyUsedWords) and Fn key is for mis-recognition
(change to voiced sound character,exchange small and large letter).

To install, double click SetupVBI2KWRT.msi.

*************************************************************************

(Japanese)
Windows10:Microsoft OCR Library for Windows を利用して
スキャナーで読み取ったイメージファイルから漢字かな混じり文を読み取り
点字編集ツール:WinBES99の入力ファイルとするかなテキストファイルを作成するツールです
かな変換機能は、辞書、頻出語のショートカット入力をサポートします
濁音欠落、大文字小文字読み違いも1キー操作で修正

インストールは SetupVBI2KWRT.msi をダブルクリックしてください
