﻿# README.md 

VBI2KWRT                 2017/12/31  V2.03

Tool of generating Japanese-Kana text file for Braille tool:WinBES99
from Kanji-Kana-Mixed text extracting from image file 
using "Microsoft OCR Library for Windows" (Windows10).
(Old version VBImage2Kana is using MODI as OCR engine,
which was deplecated. So changed to use OCR Library)

To install, double click SetupVBI2KWRT.msi.

*************************************************************************

(Japanese)
Windows10:Microsoft OCR Library for Windows を利用して
スキャナーで読み取ったイメージファイルから漢字かな混じり文を読み取り
点字編集ツール:WinBES99の入力ファイルとするかなテキストファイルを作成するツールです
(旧版 VBImage2kana は MODI で OCR していましたがサポート切れに伴い OCR ライブラリーに
変更しました)

インストールは SetupVBI2KWRT.msi をダブルクリックしてください
