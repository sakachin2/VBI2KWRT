﻿# README.md 

VBI2KWRT                 2018/02/26  V2.05

Tool of generating Japanese-Kana text file for Braille tool:WinBES99
from Kanji-Kana-Mixed text extracting from image file 
using "Microsoft OCR Library for Windows" (Windows10).
DictionaryDialog is for Mistrnslation,
WordDialog(FrequentlyUsedWords) and Fn key is for mis-recognition
(change to voiced sound character,exchange small and large letter).

To install, double click SetupVBI2KWRT.msi.

*************************************************************************

(Japanese)
Windows10:Microsoft OCR Library for Windows を利用して
スキャナーで読み取ったイメージファイルから漢字かな混じり文を読み取り
点字編集ツール:WinBES99の入力ファイルとするかなテキストファイルを作成するツールです
辞書登録機能で誤変換対応、また頻出語登録とFnキーで誤認識対応(濁音化、大文字小文字変換)

インストールは SetupVBI2KWRT.msi をダブルクリックしてください
